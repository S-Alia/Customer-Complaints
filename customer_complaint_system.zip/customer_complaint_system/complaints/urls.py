from django.urls import path
from .views import submit_complaint, success_page, admin_complaints

urlpatterns = [
    path('submit/', submit_complaint, name='submit_complaint'),
    path('success/', success_page, name='success'),
    path('admin-complaints/', admin_complaints, name='admin_complaints'),
]
