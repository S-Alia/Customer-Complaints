from django.shortcuts import render, redirect
from django.urls import reverse_lazy
from .forms import ComplaintForm
from .models import Complaint

def submit_complaint(request):
    if request.method == 'POST':
        form = ComplaintForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect(reverse_lazy('success'))
    else:
        form = ComplaintForm()
    return render(request, 'complaints/submit_complaint.html', {'form': form})

def success_page(request):
    return render(request, 'complaints/success.html')

def admin_complaints(request):
    complaints = Complaint.objects.all()
    return render(request, 'complaints/admin_complaints.html', {'complaints': complaints})
