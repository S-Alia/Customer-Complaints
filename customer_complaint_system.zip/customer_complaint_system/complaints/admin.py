from django.contrib import admin
from .models import Complaint

class ComplaintAdmin(admin.ModelAdmin):
    list_display = ('name', 'product', 'priority', 'status', 'created_at')
    list_filter = ('status', 'priority')
    search_fields = ('name', 'product', 'issue_description')

admin.site.register(Complaint, ComplaintAdmin)
